# Roadmap LNDT (open-source)

- T0 : Publication du noyau (`core/`) et packs initiaux (`domains/`)
- T0+1 : Ajout packs secteurs niche + outils de validation avancée
- T0+2 : Living benchmarks + certification tierce LNDT
- T0+3 : Foundation & gouvernance élargie
