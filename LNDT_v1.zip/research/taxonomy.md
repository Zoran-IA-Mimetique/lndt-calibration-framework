# Taxonomie LNDT — Étalo nnages (v1)

**Familles** : Classiques (benchmarks), Statistiques (calibration probabiliste),
Dynamiques (drift/continual), Multi-sources (RAG/outils), Éthique & Sociétal,
Cognitif (métacognition), Créatif (style), Réglementaire (conformité), Sectoriel,
Tech. avancées (multimodal/agents), Environnemental, Socioculturel, Expérimental.
