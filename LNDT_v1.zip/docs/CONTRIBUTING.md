# CONTRIBUTING — LNDT

Merci de votre contribution !
1. Forkez le repo, créez une branche.
2. Ajoutez/modifiez un pack dans `domains/<secteur>/pack-*.yaml`.
3. Assurez la validité : `python tools/validator.py --pack ...`
4. Ouvrez une PR décrivant les changements et sources.
