# GOVERNANCE — LNDT

- Comité noyau (core) : maintient nucleus, formats, schema.
- Comités sectoriels : maintiennent les packs par domaine.
- Process PR : 1 reviewer core + 1 reviewer secteur minimum.
- Releases : versionnement sémantique (MAJOR.MINOR.PATCH).
