# LNDT — Packs métiers (domains/)

Chaque sous-dossier contient un pack YAML conforme à `core/schema.json`.
- Un pack **étend** le nucleus (`extends_nucleus`) et définit des `prompts` avec un `fmt`.
- Pour contribuer : ouvrez une PR en suivant `docs/CONTRIBUTING.md`.

## Checklist pack
- `type: "pack"`
- `pack`, `version`, `domain`
- `extends_nucleus`: `{ id: lndt-nucleus-universel, version: "1.0.0" }`
- `prompts`: liste d’objets avec `id`, `u`, `q`, `g` (option), `fmt`, `weight` (option)
