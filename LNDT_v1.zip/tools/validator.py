#!/usr/bin/env python3
# LNDT Validator — valide un pack ou nucleus contre core/schema.json

import sys, os, json
try:
    import yaml  # pip install pyyaml
except Exception:
    yaml = None
try:
    import jsonschema  # pip install jsonschema
except Exception:
    jsonschema = None

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_yaml(path):
    if yaml is None:
        raise RuntimeError("PyYAML manquant : `pip install pyyaml`.")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def validate(doc, schema):
    if jsonschema is None:
        raise RuntimeError("jsonschema manquant : `pip install jsonschema`.")
    jsonschema.validate(instance=doc, schema=schema)

def main():
    if len(sys.argv) < 2:
        print("Usage: validator.py --pack <path.yaml> | --nucleus <path.yaml>")
        sys.exit(1)
    mode = sys.argv[1]
    target = sys.argv[2] if len(sys.argv) > 2 else None
    schema = load_json("core/schema.json")
    if mode == "--pack":
        data = load_yaml(target)
        validate(data, schema)
        print("[OK] Pack valide.")
    elif mode == "--nucleus":
        data = load_yaml(target)
        validate(data, schema)
        print("[OK] Nucleus valide.")
    else:
        print("Mode inconnu. Utilisez --pack ou --nucleus.")
        sys.exit(2)

if __name__ == "__main__":
    main()
