# Demo run — LNDT

## Pré-requis
```bash
pip install pyyaml jsonschema
```

## Valider un pack
```bash
python tools/validator.py --pack domains/insurance_btp/pack-insurance-btp-v1.yaml
```

## Valider tous les packs
```bash
python tools/runner.py
```
