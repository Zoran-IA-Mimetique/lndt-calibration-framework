#!/usr/bin/env python3
# LNDT Runner — exécute des validations sur tous les packs de domains/

import os, sys, subprocess, glob

def main():
    packs = glob.glob("domains/*/*.yaml")
    if not packs:
        print("[WARN] Aucun pack trouvé dans domains/*/*.yaml")
        sys.exit(0)
    errors = 0
    for p in packs:
        print(f"==> Validation: {p}")
        r = subprocess.run([sys.executable, "tools/validator.py", "--pack", p])
        if r.returncode != 0:
            errors += 1
    if errors == 0:
        print("[OK] Tous les packs sont valides.")
    else:
        print(f"[ERR] {errors} pack(s) invalides.")
        sys.exit(1)

if __name__ == "__main__":
    main()
