#!/usr/bin/env python3
# LNDT Injecteur — charge un pack YAML et prépare un run (exécution déléguée à runner/validator).

import sys, os, json
try:
    import yaml  # pip install pyyaml
except Exception:
    yaml = None

def load_pack(path):
    if yaml is None:
        raise RuntimeError("PyYAML manquant : installez avec `pip install pyyaml`.")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def main():
    if len(sys.argv) < 2:
        print("Usage: injecteur.py <pack.yaml>")
        sys.exit(1)
    pack_path = sys.argv[1]
    if not os.path.exists(pack_path):
        print(f"[ERR] Fichier introuvable: {pack_path}")
        sys.exit(2)
    data = load_pack(pack_path)
    print(json.dumps({"status":"loaded","type":data.get("type"),"pack":data.get("pack")}, ensure_ascii=False))

if __name__ == "__main__":
    main()
